"use client"

import { useState } from "react"
import { Copy, Download, Check, ExternalLink } from "lucide-react"

interface ScriptCardProps {
  name: string
  description: string
  script: string
}

interface ServerCardProps {
  name: string
  description: string
  link: string
}

export function ScriptCard({ name, description, script }: ScriptCardProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(script)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const blob = new Blob([script], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${name.replace(/\s+/g, "_")}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="glass-card rounded-xl p-4 flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-lg bg-pink-500/20 border border-pink-500/30 flex items-center justify-center">
          <svg
            className="w-6 h-6 text-pink-400"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="16 18 22 12 16 6" />
            <polyline points="8 6 2 12 8 18" />
          </svg>
        </div>
        <div className="flex-1">
          <h3 className="text-foreground font-semibold text-lg">{name}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
        </div>
      </div>
      
      <div className="flex gap-2">
        <button
          onClick={handleCopy}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg border border-pink-500 text-pink-400 hover:bg-pink-500/10 transition-colors font-medium"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? "Copiado" : "Copiar"}
        </button>
        <button
          onClick={handleDownload}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-pink-600 text-white hover:bg-pink-500 transition-colors font-medium"
        >
          <Download className="w-4 h-4" />
          Descargar
        </button>
      </div>
    </div>
  )
}

export function ServerCard({ name, description, link }: ServerCardProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleOpen = () => {
    window.open(link, "_blank")
  }

  return (
    <div className="glass-card rounded-xl p-4 flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center">
          <svg
            className="w-6 h-6 text-purple-400"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
            <line x1="8" y1="21" x2="16" y2="21" />
            <line x1="12" y1="17" x2="12" y2="21" />
          </svg>
        </div>
        <div className="flex-1">
          <h3 className="text-foreground font-semibold text-lg">{name}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
        </div>
      </div>
      
      <div className="flex gap-2">
        <button
          onClick={handleCopy}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg border border-purple-500 text-purple-400 hover:bg-purple-500/10 transition-colors font-medium"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? "Copiado" : "Copiar"}
        </button>
        <button
          onClick={handleOpen}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-purple-600 text-white hover:bg-purple-500 transition-colors font-medium"
        >
          <ExternalLink className="w-4 h-4" />
          Abrir
        </button>
      </div>
    </div>
  )
}
