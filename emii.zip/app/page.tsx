"use client"

import { useState, useEffect, useRef } from "react"
import { ScriptCard, ServerCard } from "@/components/script-card"
import { Menu, X } from "lucide-react"

const scripts = [
  {
    name: "Naji Hub",
    description: "Blox Fruits",
    script: `repeat wait() until game:IsLoaded() and game.Players.LocalPlayer
loadstring(game:HttpGet("https://raw.githubusercontent.com/Dev-NejiDepzai/Bloxfruits/refs/heads/main/Main.lua"))()`
  },
  {
    name: "Night Hub - Sistem Key",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://github.com/WhiteX1208/Scripts/blob/main/HopScript.luau?raw=true"))()`
  },
  {
    name: "Banana Hub",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/aloaloalo322/sssdas/refs/heads/main/cc"))()`
  },
  {
    name: "Redz Hub",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://rawscripts.net/raw/Universal-Script-New-redz-hub-138537"))()`
  },
  {
    name: "Gravity Hub",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Dev-GravityHub/BloxFruit/refs/heads/main/Main.lua"))()`
  },
  {
    name: "Zyn Hub - Sistem Key",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/jaiasof/Zyn-Hub/refs/heads/main/Zyn%20Loader", true))()`
  },
  {
    name: "OMG Hub - Sistem Key",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/Omgshit/Scripts/main/MainLoader.lua"))()`
  },
  {
    name: "Quantum Hub",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://rawscripts.net/raw/Universal-Script-Quantum-Onyx-Project-32118"))()`
  },
  {
    name: "HermanosDV - PvP",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/hermanos-dev/hermanos-hub/refs/heads/main/Loader.lua"))()`
  },
  {
    name: "Onion13 Hub - PvP",
    description: "Blox Fruits",
    script: `loadstring(game:HttpGet("https://raw.githubusercontent.com/onion132005-bit/esponion.lua/refs/heads/main/onion13v9.lua", true))()`
  },
  {
    name: "Teddy Hub - Sistem Key",
    description: "Blox Fruits",
    script: `repeat task.wait() until game:IsLoaded() and game:GetService("Players") and game.Players.LocalPlayer and game.Players.LocalPlayer:FindFirstChild("PlayerGui")
loadstring(game:HttpGet("https://raw.githubusercontent.com/Teddyseetink/Haidepzai/refs/heads/main/TEDDYHUB-FREEMIUM"))()`
  }
]

const privateServers = [
  { name: "Servidor #1", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=a507071a5b06d04da7f27e767712c44d&type=Server" },
  { name: "Servidor #2", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=54306f000d679c49aca90050ed36fc78&type=Server" },
  { name: "Servidor #3", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=e0eb5c8766a4fd4395c2304bd72d76fd&type=Server" },
  { name: "Servidor #4", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=ddb47281acea854ebab48c9ffd92f78c&type=Server" },
  { name: "Servidor #5", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=6de9a599f3c1e04f938f620a3ba27dc5&type=Server" },
  { name: "Servidor #6", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=da4be4167c2028458c2a113ca97e353e&type=Server" },
  { name: "Servidor #7", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=3898a2944ab51f4680863e66681c7f65&type=Server" },
  { name: "Servidor #8", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=8aa17971d4f7504ca13a9e1d43c10bec&type=Server" },
  { name: "Servidor #9", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=6ab6fb173e9dd64bb7986fbcaf6e0482&type=Server" },
  { name: "Servidor #10", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=b9938bb0968a57409ae1374c9ce186a1&type=Server" },
  { name: "Servidor #11", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=c14bfdd083446c4ab3d444e6c850ae52&type=Server" },
  { name: "Servidor #12", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=c6494d8a1b23734cac71c07fd4c53ef8&type=Server" },
  { name: "Servidor #13", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=acc8b9ba1ca48c428e852b904b40fbc9&type=Server" },
  { name: "Servidor #14", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=328d45726b08ed44a2885f10be38e7a6&type=Server" },
  { name: "Servidor #15", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=d03daac226b17a4a97f656f1ec9b2c74&type=Server" },
  { name: "Servidor #16", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=b9fa0ca0e1475f4da5b228cd33f2a8f3&type=Server" },
  { name: "Servidor #17", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=7176380f1d691f46b4f2da4c7ff0dd1a&type=Server" },
  { name: "Servidor #18", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=3b07e01813dc7a4e860fe2b3db5326d7&type=Server" },
  { name: "Servidor #19", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=6fa4b0c1f5cf4e40b9a49c80d0bdfc5a&type=Server" },
  { name: "Servidor #20", description: "Servidor privado de Blox Fruits", link: "https://www.roblox.com/share?code=7c724c87730dae45bf5199ecf4c39d2b&type=Server" },
]

function FloatingParticles() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {[...Array(15)].map((_, i) => (
        <div
          key={i}
          className="particle absolute text-pink-400/40"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 4}s`,
            fontSize: `${Math.random() * 16 + 10}px`,
          }}
        >
          {i % 3 === 0 ? "✦" : i % 3 === 1 ? "❀" : "✧"}
        </div>
      ))}
    </div>
  )
}

export default function Page() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState<"scripts" | "servers">("scripts")
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    const audio = audioRef.current
    if (audio) {
      audio.volume = 0.15
      audio.loop = true
      
      const playAudio = () => {
        audio.play().catch(() => {
          // Autoplay blocked, will play on first interaction
        })
      }
      
      playAudio()
      
      const handleInteraction = () => {
        audio.play().catch(() => {})
        document.removeEventListener("click", handleInteraction)
      }
      document.addEventListener("click", handleInteraction)
      
      return () => {
        document.removeEventListener("click", handleInteraction)
      }
    }
  }, [])

  const navigateTo = (page: "scripts" | "servers") => {
    setCurrentPage(page)
    setSidebarOpen(false)
  }

  return (
    <main className="min-h-screen bg-background bg-glow relative">
      <audio ref={audioRef} src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nevada-%28SlowedReverb%29-WXaiDr016PKBZDcOlyftZTKmWatdp8.mp3" />
      <FloatingParticles />
      
      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full w-72 bg-background/95 backdrop-blur-lg border-r border-pink-500/30 z-50 transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Menu</h2>
            <button onClick={() => setSidebarOpen(false)} className="text-foreground hover:text-pink-400 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <nav className="flex flex-col gap-2">
            <button
              onClick={() => navigateTo("scripts")}
              className={`text-left px-4 py-3 rounded-lg transition-colors ${currentPage === "scripts" ? "bg-pink-500/20 text-pink-400 border border-pink-500/30" : "text-foreground hover:bg-pink-500/10"}`}
            >
              Scripts | BloxFruits
            </button>
            <button
              onClick={() => navigateTo("servers")}
              className={`text-left px-4 py-3 rounded-lg transition-colors ${currentPage === "servers" ? "bg-purple-500/20 text-purple-400 border border-purple-500/30" : "text-foreground hover:bg-purple-500/10"}`}
            >
              Servidores Privados
            </button>
          </nav>
        </div>
      </aside>

      <div className="max-w-2xl mx-auto px-4 py-8 relative z-10">
        {/* Top Bar */}
        <div className="flex items-center justify-start mb-6">
          <button 
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-pink-500/10 transition-colors"
          >
            <Menu className="w-6 h-6 text-pink-400" />
          </button>
        </div>

        {/* Profile Section */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-pink-500/50 glow-border mb-4">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/582b91606ea5ceb747a0548559894570-81C4Rp841EKqYV9KGDyLIxa63ZQpNk.jpg"
              alt="emiinathalie"
              className="w-full h-full object-cover"
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-400 via-purple-400 to-blue-300 bg-clip-text text-transparent mb-2">
            {currentPage === "scripts" ? "Scripts | BloxFruits" : "Servidores Privados"}
          </h1>
          <p className="text-pink-300/80 text-sm">@emiinathalie</p>
        </div>

        {/* Warning Message */}
        <div className="text-center mb-6">
          <p className="text-amber-400 text-sm md:text-base leading-relaxed">
            {currentPage === "scripts" ? (
              <>
                Todo uso de script puede ser baneable si abusas de ellos.
                <br />
                Recomendable no abusar y usarlo en servidores privados.
              </>
            ) : (
              <>
                Si dejan de funcionar es porque no se han pagado todavia,
                <br />
                solo les toca esperar a que se reactiven.
              </>
            )}
          </p>
        </div>

        {/* Social Icons */}
        <div className="flex justify-center gap-4 mb-10">
          <a
            href="https://whatsapp.com/channel/0029VbCke8qKQuJQ9L3rR30z"
            target="_blank"
            rel="noopener noreferrer"
            className="w-12 h-12 rounded-full glass-card flex items-center justify-center text-foreground hover:border-green-500/50 hover:text-green-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
          </a>
          <a
            href="https://www.tiktok.com/@emiinathalie"
            target="_blank"
            rel="noopener noreferrer"
            className="w-12 h-12 rounded-full glass-card flex items-center justify-center text-foreground hover:border-pink-500/50 hover:text-pink-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/>
            </svg>
          </a>
        </div>

        {/* Content */}
        {currentPage === "scripts" ? (
          <>
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-6">
              Scripts | BloxFruits
            </h2>
            <div className="flex flex-col gap-4">
              {scripts.map((script, index) => (
                <ScriptCard
                  key={index}
                  name={script.name}
                  description={script.description}
                  script={script.script}
                />
              ))}
            </div>
          </>
        ) : (
          <>
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-6">
              Servidores Privados
            </h2>
            <div className="flex flex-col gap-4">
              {privateServers.map((server, index) => (
                <ServerCard
                  key={index}
                  name={server.name}
                  description={server.description}
                  link={server.link}
                />
              ))}
            </div>
          </>
        )}

        {/* Footer */}
        <footer className="mt-12 text-center text-muted-foreground text-sm">
          <p className="bg-gradient-to-r from-pink-400/60 to-purple-400/60 bg-clip-text text-transparent">
            @emiinathalie - Scripts | BloxFruits
          </p>
        </footer>
      </div>
    </main>
  )
}
